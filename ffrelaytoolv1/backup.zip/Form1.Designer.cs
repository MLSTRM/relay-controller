﻿namespace ffrelaytoolv1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.MainTimer = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.startbutton = new System.Windows.Forms.Button();
            this.TonbIconbutton = new System.Windows.Forms.Button();
            this.TonbIconlabel = new System.Windows.Forms.Label();
            this.stopbutton = new System.Windows.Forms.Button();
            this.MogIconbutton = new System.Windows.Forms.Button();
            this.ChocoIconbutton = new System.Windows.Forms.Button();
            this.MogIconlabel = new System.Windows.Forms.Label();
            this.ChocoIconlabel = new System.Windows.Forms.Label();
            this.infomog = new System.Windows.Forms.TabControl();
            this.mogsplits = new System.Windows.Forms.TabPage();
            this.MogSplitName7 = new System.Windows.Forms.Label();
            this.MogSplitName6 = new System.Windows.Forms.Label();
            this.MogSplitVs2 = new System.Windows.Forms.Label();
            this.MogSplitVs1 = new System.Windows.Forms.Label();
            this.MogSplitTime4 = new System.Windows.Forms.Label();
            this.MogSplitName4 = new System.Windows.Forms.Label();
            this.MogSplitTime3 = new System.Windows.Forms.Label();
            this.MogSplitTime2 = new System.Windows.Forms.Label();
            this.MogSplitTime1 = new System.Windows.Forms.Label();
            this.MogSplitName3 = new System.Windows.Forms.Label();
            this.MogSplitName2 = new System.Windows.Forms.Label();
            this.MogSplitName1 = new System.Windows.Forms.Label();
            this.mogcategory = new System.Windows.Forms.TabPage();
            this.MogCommentary = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.MogInfoCat2 = new System.Windows.Forms.Label();
            this.MogInfoCat1 = new System.Windows.Forms.Label();
            this.MogInfoCat3 = new System.Windows.Forms.Label();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.MogGameTimersL = new System.Windows.Forms.Label();
            this.MogGameTimersR = new System.Windows.Forms.Label();
            this.MogGameTimers2M = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.MogGameEndL = new System.Windows.Forms.Label();
            this.MogGameEnd2M = new System.Windows.Forms.Label();
            this.MogGameEndR = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.infochoco = new System.Windows.Forms.TabControl();
            this.chocosplits = new System.Windows.Forms.TabPage();
            this.label33 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.ChocoSplitVs2 = new System.Windows.Forms.Label();
            this.ChocoSplitVs1 = new System.Windows.Forms.Label();
            this.ChocoSplitTime4 = new System.Windows.Forms.Label();
            this.ChocoSplitName4 = new System.Windows.Forms.Label();
            this.ChocoSplitTime3 = new System.Windows.Forms.Label();
            this.ChocoSplitTime2 = new System.Windows.Forms.Label();
            this.ChocoSplitTime1 = new System.Windows.Forms.Label();
            this.ChocoSplitName3 = new System.Windows.Forms.Label();
            this.ChocoSplitName2 = new System.Windows.Forms.Label();
            this.ChocoSplitName1 = new System.Windows.Forms.Label();
            this.chococategory = new System.Windows.Forms.TabPage();
            this.ChocoCommentary = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.ChocoInfoCat3 = new System.Windows.Forms.Label();
            this.ChocoInfoCat2 = new System.Windows.Forms.Label();
            this.ChocoInfoCat1 = new System.Windows.Forms.Label();
            this.chocogames = new System.Windows.Forms.TabPage();
            this.ChocoGameTimersL = new System.Windows.Forms.Label();
            this.ChocoGameTimersR = new System.Windows.Forms.Label();
            this.ChocoGameTimers2M = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tabPage7 = new System.Windows.Forms.TabPage();
            this.ChocoGameEndL = new System.Windows.Forms.Label();
            this.ChocoGameEndR = new System.Windows.Forms.Label();
            this.ChocoGameEnd2M = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.MogSplit = new System.Windows.Forms.Button();
            this.ChocoSplit = new System.Windows.Forms.Button();
            this.MogTimer = new System.Windows.Forms.Label();
            this.ChocoTimer = new System.Windows.Forms.Label();
            this.TonbTimer = new System.Windows.Forms.Label();
            this.infotonb = new System.Windows.Forms.TabControl();
            this.tabPage9 = new System.Windows.Forms.TabPage();
            this.TonbSplitVs2 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.TonbSplitVs1 = new System.Windows.Forms.Label();
            this.TonbSplitTime4 = new System.Windows.Forms.Label();
            this.TonbSplitName4 = new System.Windows.Forms.Label();
            this.TonbSplitTime3 = new System.Windows.Forms.Label();
            this.TonbSplitTime2 = new System.Windows.Forms.Label();
            this.TonbSplitTime1 = new System.Windows.Forms.Label();
            this.TonbSplitName3 = new System.Windows.Forms.Label();
            this.TonbSplitName2 = new System.Windows.Forms.Label();
            this.TonbSplitName1 = new System.Windows.Forms.Label();
            this.tabPage10 = new System.Windows.Forms.TabPage();
            this.TonbCommentary = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.TonbInfoCat3 = new System.Windows.Forms.Label();
            this.TonbInfoCat2 = new System.Windows.Forms.Label();
            this.TonbInfoCat1 = new System.Windows.Forms.Label();
            this.tabPage11 = new System.Windows.Forms.TabPage();
            this.TonbGameTimersL = new System.Windows.Forms.Label();
            this.TonbGameTimersR = new System.Windows.Forms.Label();
            this.TonbGameTimers2M = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.tabPage14 = new System.Windows.Forms.TabPage();
            this.TonbGameEndL = new System.Windows.Forms.Label();
            this.TonbGameEndR = new System.Windows.Forms.Label();
            this.TonbGameEnd2M = new System.Windows.Forms.Label();
            this.label60 = new System.Windows.Forms.Label();
            this.label61 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.TonbSplit = new System.Windows.Forms.Button();
            this.CommUpdate = new System.Windows.Forms.Button();
            this.infomog.SuspendLayout();
            this.mogsplits.SuspendLayout();
            this.mogcategory.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.infochoco.SuspendLayout();
            this.chocosplits.SuspendLayout();
            this.chococategory.SuspendLayout();
            this.chocogames.SuspendLayout();
            this.tabPage7.SuspendLayout();
            this.infotonb.SuspendLayout();
            this.tabPage9.SuspendLayout();
            this.tabPage10.SuspendLayout();
            this.tabPage11.SuspendLayout();
            this.tabPage14.SuspendLayout();
            this.SuspendLayout();
            // 
            // MainTimer
            // 
            this.MainTimer.BackColor = System.Drawing.Color.White;
            this.MainTimer.Font = new System.Drawing.Font("Microsoft Sans Serif", 60F);
            this.MainTimer.Location = new System.Drawing.Point(12, 22);
            this.MainTimer.Margin = new System.Windows.Forms.Padding(0);
            this.MainTimer.Name = "MainTimer";
            this.MainTimer.Size = new System.Drawing.Size(360, 90);
            this.MainTimer.TabIndex = 0;
            this.MainTimer.Text = "00:00:00";
            this.MainTimer.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 6);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(59, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Main Timer";
            // 
            // startbutton
            // 
            this.startbutton.Location = new System.Drawing.Point(381, 22);
            this.startbutton.Name = "startbutton";
            this.startbutton.Size = new System.Drawing.Size(50, 90);
            this.startbutton.TabIndex = 2;
            this.startbutton.Text = "Timer Start";
            this.startbutton.UseVisualStyleBackColor = true;
            this.startbutton.Click += new System.EventHandler(this.button1_Click);
            // 
            // TonbIconbutton
            // 
            this.TonbIconbutton.BackColor = System.Drawing.Color.ForestGreen;
            this.TonbIconbutton.Location = new System.Drawing.Point(730, 23);
            this.TonbIconbutton.Name = "TonbIconbutton";
            this.TonbIconbutton.Size = new System.Drawing.Size(76, 50);
            this.TonbIconbutton.TabIndex = 3;
            this.TonbIconbutton.Text = "Change Tonb Icon";
            this.TonbIconbutton.UseVisualStyleBackColor = false;
            this.TonbIconbutton.Click += new System.EventHandler(this.tonbIconButton_Click);
            // 
            // TonbIconlabel
            // 
            this.TonbIconlabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.TonbIconlabel.Location = new System.Drawing.Point(730, 76);
            this.TonbIconlabel.Name = "TonbIconlabel";
            this.TonbIconlabel.Size = new System.Drawing.Size(81, 28);
            this.TonbIconlabel.TabIndex = 5;
            this.TonbIconlabel.Text = "Cur: 1";
            // 
            // stopbutton
            // 
            this.stopbutton.Location = new System.Drawing.Point(456, 23);
            this.stopbutton.Name = "stopbutton";
            this.stopbutton.Size = new System.Drawing.Size(61, 89);
            this.stopbutton.TabIndex = 6;
            this.stopbutton.Text = "Timer Stop";
            this.stopbutton.UseVisualStyleBackColor = true;
            this.stopbutton.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // MogIconbutton
            // 
            this.MogIconbutton.BackColor = System.Drawing.Color.CornflowerBlue;
            this.MogIconbutton.Location = new System.Drawing.Point(566, 23);
            this.MogIconbutton.Name = "MogIconbutton";
            this.MogIconbutton.Size = new System.Drawing.Size(76, 50);
            this.MogIconbutton.TabIndex = 7;
            this.MogIconbutton.Text = "Change Mog Icon";
            this.MogIconbutton.UseVisualStyleBackColor = false;
            this.MogIconbutton.Click += new System.EventHandler(this.hbbutton_Click);
            // 
            // ChocoIconbutton
            // 
            this.ChocoIconbutton.BackColor = System.Drawing.Color.Orchid;
            this.ChocoIconbutton.Location = new System.Drawing.Point(648, 23);
            this.ChocoIconbutton.Name = "ChocoIconbutton";
            this.ChocoIconbutton.Size = new System.Drawing.Size(76, 50);
            this.ChocoIconbutton.TabIndex = 8;
            this.ChocoIconbutton.Text = "Change Choco Icon";
            this.ChocoIconbutton.UseVisualStyleBackColor = false;
            this.ChocoIconbutton.Click += new System.EventHandler(this.hpbutton_Click);
            // 
            // MogIconlabel
            // 
            this.MogIconlabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.MogIconlabel.Location = new System.Drawing.Point(561, 76);
            this.MogIconlabel.Name = "MogIconlabel";
            this.MogIconlabel.Size = new System.Drawing.Size(81, 28);
            this.MogIconlabel.TabIndex = 9;
            this.MogIconlabel.Text = "Cur: 1";
            // 
            // ChocoIconlabel
            // 
            this.ChocoIconlabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.ChocoIconlabel.Location = new System.Drawing.Point(643, 76);
            this.ChocoIconlabel.Name = "ChocoIconlabel";
            this.ChocoIconlabel.Size = new System.Drawing.Size(81, 28);
            this.ChocoIconlabel.TabIndex = 10;
            this.ChocoIconlabel.Text = "Cur: 1";
            // 
            // infomog
            // 
            this.infomog.Controls.Add(this.mogsplits);
            this.infomog.Controls.Add(this.mogcategory);
            this.infomog.Controls.Add(this.tabPage1);
            this.infomog.Controls.Add(this.tabPage5);
            this.infomog.Location = new System.Drawing.Point(12, 295);
            this.infomog.Name = "infomog";
            this.infomog.SelectedIndex = 0;
            this.infomog.Size = new System.Drawing.Size(408, 254);
            this.infomog.TabIndex = 11;
            this.infomog.Selected += new System.Windows.Forms.TabControlEventHandler(this.MogTab_Clicked);
            // 
            // mogsplits
            // 
            this.mogsplits.BackColor = System.Drawing.Color.Black;
            this.mogsplits.BackgroundImage = global::ffrelaytoolv1.Properties.Resources.mog_box;
            this.mogsplits.Controls.Add(this.MogSplitName7);
            this.mogsplits.Controls.Add(this.MogSplitName6);
            this.mogsplits.Controls.Add(this.MogSplitVs2);
            this.mogsplits.Controls.Add(this.MogSplitVs1);
            this.mogsplits.Controls.Add(this.MogSplitTime4);
            this.mogsplits.Controls.Add(this.MogSplitName4);
            this.mogsplits.Controls.Add(this.MogSplitTime3);
            this.mogsplits.Controls.Add(this.MogSplitTime2);
            this.mogsplits.Controls.Add(this.MogSplitTime1);
            this.mogsplits.Controls.Add(this.MogSplitName3);
            this.mogsplits.Controls.Add(this.MogSplitName2);
            this.mogsplits.Controls.Add(this.MogSplitName1);
            this.mogsplits.Location = new System.Drawing.Point(4, 22);
            this.mogsplits.Name = "mogsplits";
            this.mogsplits.Padding = new System.Windows.Forms.Padding(3);
            this.mogsplits.Size = new System.Drawing.Size(400, 228);
            this.mogsplits.TabIndex = 0;
            this.mogsplits.Text = "M: Splits";
            // 
            // MogSplitName7
            // 
            this.MogSplitName7.BackColor = System.Drawing.Color.Transparent;
            this.MogSplitName7.Font = new System.Drawing.Font("Lucida Sans Typewriter", 16F);
            this.MogSplitName7.ForeColor = System.Drawing.Color.White;
            this.MogSplitName7.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.MogSplitName7.Location = new System.Drawing.Point(3, 186);
            this.MogSplitName7.Name = "MogSplitName7";
            this.MogSplitName7.Size = new System.Drawing.Size(228, 29);
            this.MogSplitName7.TabIndex = 15;
            this.MogSplitName7.Text = "Team Tonberry:";
            this.MogSplitName7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // MogSplitName6
            // 
            this.MogSplitName6.BackColor = System.Drawing.Color.Transparent;
            this.MogSplitName6.Font = new System.Drawing.Font("Lucida Sans Typewriter", 16F);
            this.MogSplitName6.ForeColor = System.Drawing.Color.White;
            this.MogSplitName6.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.MogSplitName6.Location = new System.Drawing.Point(3, 157);
            this.MogSplitName6.Name = "MogSplitName6";
            this.MogSplitName6.Size = new System.Drawing.Size(230, 29);
            this.MogSplitName6.TabIndex = 14;
            this.MogSplitName6.Text = "Team Choco:";
            this.MogSplitName6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // MogSplitVs2
            // 
            this.MogSplitVs2.BackColor = System.Drawing.Color.Transparent;
            this.MogSplitVs2.Font = new System.Drawing.Font("Lucida Sans Typewriter", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MogSplitVs2.ForeColor = System.Drawing.Color.White;
            this.MogSplitVs2.Location = new System.Drawing.Point(242, 186);
            this.MogSplitVs2.Name = "MogSplitVs2";
            this.MogSplitVs2.Size = new System.Drawing.Size(140, 29);
            this.MogSplitVs2.TabIndex = 12;
            this.MogSplitVs2.Text = "00:00:00";
            this.MogSplitVs2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // MogSplitVs1
            // 
            this.MogSplitVs1.BackColor = System.Drawing.Color.Transparent;
            this.MogSplitVs1.Font = new System.Drawing.Font("Lucida Sans Typewriter", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MogSplitVs1.ForeColor = System.Drawing.Color.White;
            this.MogSplitVs1.Location = new System.Drawing.Point(242, 157);
            this.MogSplitVs1.Name = "MogSplitVs1";
            this.MogSplitVs1.Size = new System.Drawing.Size(140, 29);
            this.MogSplitVs1.TabIndex = 11;
            this.MogSplitVs1.Text = "00:00:00";
            this.MogSplitVs1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // MogSplitTime4
            // 
            this.MogSplitTime4.BackColor = System.Drawing.Color.Transparent;
            this.MogSplitTime4.Font = new System.Drawing.Font("Lucida Sans Typewriter", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MogSplitTime4.ForeColor = System.Drawing.Color.White;
            this.MogSplitTime4.Location = new System.Drawing.Point(265, 96);
            this.MogSplitTime4.Name = "MogSplitTime4";
            this.MogSplitTime4.Size = new System.Drawing.Size(117, 29);
            this.MogSplitTime4.TabIndex = 9;
            this.MogSplitTime4.Text = "00:00:00";
            this.MogSplitTime4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // MogSplitName4
            // 
            this.MogSplitName4.BackColor = System.Drawing.Color.Transparent;
            this.MogSplitName4.Font = new System.Drawing.Font("Lucida Sans Typewriter", 16F);
            this.MogSplitName4.ForeColor = System.Drawing.Color.White;
            this.MogSplitName4.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.MogSplitName4.Location = new System.Drawing.Point(3, 96);
            this.MogSplitName4.Name = "MogSplitName4";
            this.MogSplitName4.Size = new System.Drawing.Size(256, 29);
            this.MogSplitName4.TabIndex = 8;
            this.MogSplitName4.Text = "Final Fantasy T-0";
            this.MogSplitName4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // MogSplitTime3
            // 
            this.MogSplitTime3.BackColor = System.Drawing.Color.Transparent;
            this.MogSplitTime3.Font = new System.Drawing.Font("Lucida Sans Typewriter", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MogSplitTime3.ForeColor = System.Drawing.Color.White;
            this.MogSplitTime3.Location = new System.Drawing.Point(265, 66);
            this.MogSplitTime3.Name = "MogSplitTime3";
            this.MogSplitTime3.Size = new System.Drawing.Size(117, 29);
            this.MogSplitTime3.TabIndex = 7;
            this.MogSplitTime3.Text = "00:00:00";
            this.MogSplitTime3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // MogSplitTime2
            // 
            this.MogSplitTime2.BackColor = System.Drawing.Color.Transparent;
            this.MogSplitTime2.Font = new System.Drawing.Font("Lucida Sans Typewriter", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MogSplitTime2.ForeColor = System.Drawing.Color.White;
            this.MogSplitTime2.Location = new System.Drawing.Point(265, 36);
            this.MogSplitTime2.Name = "MogSplitTime2";
            this.MogSplitTime2.Size = new System.Drawing.Size(117, 29);
            this.MogSplitTime2.TabIndex = 6;
            this.MogSplitTime2.Text = "00:00:00";
            this.MogSplitTime2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // MogSplitTime1
            // 
            this.MogSplitTime1.BackColor = System.Drawing.Color.Transparent;
            this.MogSplitTime1.Font = new System.Drawing.Font("Lucida Sans Typewriter", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MogSplitTime1.ForeColor = System.Drawing.Color.White;
            this.MogSplitTime1.Location = new System.Drawing.Point(265, 6);
            this.MogSplitTime1.Name = "MogSplitTime1";
            this.MogSplitTime1.Size = new System.Drawing.Size(117, 29);
            this.MogSplitTime1.TabIndex = 5;
            this.MogSplitTime1.Text = "00:00:00";
            this.MogSplitTime1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // MogSplitName3
            // 
            this.MogSplitName3.BackColor = System.Drawing.Color.Transparent;
            this.MogSplitName3.Font = new System.Drawing.Font("Lucida Sans Typewriter", 16F);
            this.MogSplitName3.ForeColor = System.Drawing.Color.White;
            this.MogSplitName3.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.MogSplitName3.Location = new System.Drawing.Point(3, 66);
            this.MogSplitName3.Name = "MogSplitName3";
            this.MogSplitName3.Size = new System.Drawing.Size(256, 29);
            this.MogSplitName3.TabIndex = 4;
            this.MogSplitName3.Text = "Final Fantasy T0HD";
            this.MogSplitName3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // MogSplitName2
            // 
            this.MogSplitName2.BackColor = System.Drawing.Color.Transparent;
            this.MogSplitName2.Font = new System.Drawing.Font("Lucida Sans Typewriter", 16F);
            this.MogSplitName2.ForeColor = System.Drawing.Color.White;
            this.MogSplitName2.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.MogSplitName2.Location = new System.Drawing.Point(3, 36);
            this.MogSplitName2.Name = "MogSplitName2";
            this.MogSplitName2.Size = new System.Drawing.Size(256, 29);
            this.MogSplitName2.TabIndex = 3;
            this.MogSplitName2.Text = "FF Type-0 HD";
            this.MogSplitName2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // MogSplitName1
            // 
            this.MogSplitName1.BackColor = System.Drawing.Color.Transparent;
            this.MogSplitName1.Font = new System.Drawing.Font("Lucida Sans Typewriter", 16F);
            this.MogSplitName1.ForeColor = System.Drawing.Color.White;
            this.MogSplitName1.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.MogSplitName1.Location = new System.Drawing.Point(3, 6);
            this.MogSplitName1.Name = "MogSplitName1";
            this.MogSplitName1.Size = new System.Drawing.Size(256, 29);
            this.MogSplitName1.TabIndex = 2;
            this.MogSplitName1.Text = "Lightning Returns";
            this.MogSplitName1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // mogcategory
            // 
            this.mogcategory.BackColor = System.Drawing.Color.Black;
            this.mogcategory.BackgroundImage = global::ffrelaytoolv1.Properties.Resources.mog_box;
            this.mogcategory.Controls.Add(this.MogCommentary);
            this.mogcategory.Controls.Add(this.label37);
            this.mogcategory.Controls.Add(this.MogInfoCat2);
            this.mogcategory.Controls.Add(this.MogInfoCat1);
            this.mogcategory.Controls.Add(this.MogInfoCat3);
            this.mogcategory.Location = new System.Drawing.Point(4, 22);
            this.mogcategory.Name = "mogcategory";
            this.mogcategory.Padding = new System.Windows.Forms.Padding(3);
            this.mogcategory.Size = new System.Drawing.Size(400, 228);
            this.mogcategory.TabIndex = 1;
            this.mogcategory.Text = "M: Cats";
            // 
            // MogCommentary
            // 
            this.MogCommentary.BackColor = System.Drawing.Color.Transparent;
            this.MogCommentary.Font = new System.Drawing.Font("Lucida Sans Typewriter", 16F);
            this.MogCommentary.ForeColor = System.Drawing.Color.White;
            this.MogCommentary.Location = new System.Drawing.Point(3, 143);
            this.MogCommentary.Name = "MogCommentary";
            this.MogCommentary.Size = new System.Drawing.Size(394, 84);
            this.MogCommentary.TabIndex = 7;
            this.MogCommentary.Text = "Commentators";
            this.MogCommentary.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label37
            // 
            this.label37.BackColor = System.Drawing.Color.Transparent;
            this.label37.Font = new System.Drawing.Font("Lucida Sans Typewriter", 16F);
            this.label37.ForeColor = System.Drawing.Color.White;
            this.label37.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.label37.Location = new System.Drawing.Point(3, 108);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(391, 35);
            this.label37.TabIndex = 6;
            this.label37.Text = "Commentators:";
            this.label37.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // MogInfoCat2
            // 
            this.MogInfoCat2.BackColor = System.Drawing.Color.Transparent;
            this.MogInfoCat2.Font = new System.Drawing.Font("Lucida Sans Typewriter", 16F);
            this.MogInfoCat2.ForeColor = System.Drawing.Color.White;
            this.MogInfoCat2.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.MogInfoCat2.Location = new System.Drawing.Point(3, 38);
            this.MogInfoCat2.Name = "MogInfoCat2";
            this.MogInfoCat2.Size = new System.Drawing.Size(391, 35);
            this.MogInfoCat2.TabIndex = 2;
            this.MogInfoCat2.Text = "MogCategory";
            this.MogInfoCat2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // MogInfoCat1
            // 
            this.MogInfoCat1.BackColor = System.Drawing.Color.Transparent;
            this.MogInfoCat1.Font = new System.Drawing.Font("Lucida Sans Typewriter", 16F);
            this.MogInfoCat1.ForeColor = System.Drawing.Color.White;
            this.MogInfoCat1.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.MogInfoCat1.Location = new System.Drawing.Point(3, 3);
            this.MogInfoCat1.Name = "MogInfoCat1";
            this.MogInfoCat1.Size = new System.Drawing.Size(391, 35);
            this.MogInfoCat1.TabIndex = 1;
            this.MogInfoCat1.Text = "MogCategory";
            this.MogInfoCat1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // MogInfoCat3
            // 
            this.MogInfoCat3.BackColor = System.Drawing.Color.Transparent;
            this.MogInfoCat3.Font = new System.Drawing.Font("Lucida Sans Typewriter", 16F);
            this.MogInfoCat3.ForeColor = System.Drawing.Color.White;
            this.MogInfoCat3.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.MogInfoCat3.Location = new System.Drawing.Point(3, 73);
            this.MogInfoCat3.Name = "MogInfoCat3";
            this.MogInfoCat3.Size = new System.Drawing.Size(391, 35);
            this.MogInfoCat3.TabIndex = 0;
            this.MogInfoCat3.Text = "MogCategory";
            this.MogInfoCat3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.Black;
            this.tabPage1.BackgroundImage = global::ffrelaytoolv1.Properties.Resources.mog_box;
            this.tabPage1.Controls.Add(this.MogGameTimersL);
            this.tabPage1.Controls.Add(this.MogGameTimersR);
            this.tabPage1.Controls.Add(this.MogGameTimers2M);
            this.tabPage1.Controls.Add(this.label9);
            this.tabPage1.Controls.Add(this.label8);
            this.tabPage1.Controls.Add(this.label7);
            this.tabPage1.Controls.Add(this.label6);
            this.tabPage1.Controls.Add(this.label5);
            this.tabPage1.Controls.Add(this.label4);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(400, 228);
            this.tabPage1.TabIndex = 3;
            this.tabPage1.Text = "M: Times";
            // 
            // MogGameTimersL
            // 
            this.MogGameTimersL.BackColor = System.Drawing.Color.Transparent;
            this.MogGameTimersL.Font = new System.Drawing.Font("Lucida Sans Typewriter", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MogGameTimersL.ForeColor = System.Drawing.Color.White;
            this.MogGameTimersL.Location = new System.Drawing.Point(76, 23);
            this.MogGameTimersL.Name = "MogGameTimersL";
            this.MogGameTimersL.Size = new System.Drawing.Size(109, 170);
            this.MogGameTimersL.TabIndex = 32;
            this.MogGameTimersL.Text = "00:00:00\r\n00:00:00\r\n00:00:00\r\n00:00:00\r\n00:00:00\r\n00:00:00\r\n00:00:00\r\n00:00:00";
            this.MogGameTimersL.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // MogGameTimersR
            // 
            this.MogGameTimersR.BackColor = System.Drawing.Color.Transparent;
            this.MogGameTimersR.Font = new System.Drawing.Font("Lucida Sans Typewriter", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MogGameTimersR.ForeColor = System.Drawing.Color.White;
            this.MogGameTimersR.Location = new System.Drawing.Point(204, 23);
            this.MogGameTimersR.Name = "MogGameTimersR";
            this.MogGameTimersR.Size = new System.Drawing.Size(109, 170);
            this.MogGameTimersR.TabIndex = 31;
            this.MogGameTimersR.Text = "00:00:00\r\n00:00:00\r\n00:00:00\r\n00:00:00\r\n00:00:00\r\n00:00:00\r\n00:00:00\r\n00:00:00";
            this.MogGameTimersR.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // MogGameTimers2M
            // 
            this.MogGameTimers2M.BackColor = System.Drawing.Color.Transparent;
            this.MogGameTimers2M.Font = new System.Drawing.Font("Lucida Sans Typewriter", 13F);
            this.MogGameTimers2M.ForeColor = System.Drawing.Color.White;
            this.MogGameTimers2M.Location = new System.Drawing.Point(145, 194);
            this.MogGameTimers2M.Name = "MogGameTimers2M";
            this.MogGameTimers2M.Size = new System.Drawing.Size(110, 21);
            this.MogGameTimers2M.TabIndex = 8;
            this.MogGameTimers2M.Text = "00:00:00";
            this.MogGameTimers2M.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label9
            // 
            this.label9.BackColor = System.Drawing.Color.Transparent;
            this.label9.Font = new System.Drawing.Font("Lucida Sans Typewriter", 13F);
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.label9.Location = new System.Drawing.Point(76, 194);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(90, 21);
            this.label9.TabIndex = 11;
            this.label9.Text = "XV : ";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label8
            // 
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Font = new System.Drawing.Font("Lucida Sans Typewriter", 13F);
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(295, 108);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(90, 80);
            this.label8.TabIndex = 10;
            this.label8.Text = " : XIII\r\n : 13-2\r\n : LR\r\n : T-0";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label7
            // 
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Lucida Sans Typewriter", 13F);
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(3, 108);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(90, 80);
            this.label7.TabIndex = 9;
            this.label7.Text = "V : \r\nVI : \r\nVII : \r\nVIII : ";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label6
            // 
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Lucida Sans Typewriter", 13F);
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(295, 24);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(90, 80);
            this.label6.TabIndex = 5;
            this.label6.Text = " : IX\r\n : X\r\n : X-2\r\n : XII";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label5
            // 
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Lucida Sans Typewriter", 13F);
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(3, 24);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(90, 80);
            this.label5.TabIndex = 1;
            this.label5.Text = "I : \r\nII : \r\nIII : \r\nIV : ";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label4
            // 
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Lucida Sans Typewriter", 13F);
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(3, 3);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(394, 21);
            this.label4.TabIndex = 0;
            this.label4.Text = "Game Times";
            this.label4.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // tabPage5
            // 
            this.tabPage5.BackColor = System.Drawing.Color.Black;
            this.tabPage5.BackgroundImage = global::ffrelaytoolv1.Properties.Resources.mog_box;
            this.tabPage5.Controls.Add(this.MogGameEndL);
            this.tabPage5.Controls.Add(this.MogGameEnd2M);
            this.tabPage5.Controls.Add(this.MogGameEndR);
            this.tabPage5.Controls.Add(this.label22);
            this.tabPage5.Controls.Add(this.label18);
            this.tabPage5.Controls.Add(this.label15);
            this.tabPage5.Controls.Add(this.label16);
            this.tabPage5.Controls.Add(this.label17);
            this.tabPage5.Controls.Add(this.label14);
            this.tabPage5.Location = new System.Drawing.Point(4, 22);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(400, 228);
            this.tabPage5.TabIndex = 5;
            this.tabPage5.Text = "M: End";
            // 
            // MogGameEndL
            // 
            this.MogGameEndL.BackColor = System.Drawing.Color.Transparent;
            this.MogGameEndL.Font = new System.Drawing.Font("Lucida Sans Typewriter", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MogGameEndL.ForeColor = System.Drawing.Color.White;
            this.MogGameEndL.Location = new System.Drawing.Point(76, 23);
            this.MogGameEndL.Name = "MogGameEndL";
            this.MogGameEndL.Size = new System.Drawing.Size(109, 170);
            this.MogGameEndL.TabIndex = 30;
            this.MogGameEndL.Text = "00:00:00\r\n00:00:00\r\n00:00:00\r\n00:00:00\r\n00:00:00\r\n00:00:00\r\n00:00:00\r\n00:00:00";
            this.MogGameEndL.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // MogGameEnd2M
            // 
            this.MogGameEnd2M.BackColor = System.Drawing.Color.Transparent;
            this.MogGameEnd2M.Font = new System.Drawing.Font("Lucida Sans Typewriter", 13F);
            this.MogGameEnd2M.ForeColor = System.Drawing.Color.White;
            this.MogGameEnd2M.Location = new System.Drawing.Point(145, 194);
            this.MogGameEnd2M.Name = "MogGameEnd2M";
            this.MogGameEnd2M.Size = new System.Drawing.Size(110, 21);
            this.MogGameEnd2M.TabIndex = 17;
            this.MogGameEnd2M.Text = "00:00:00";
            this.MogGameEnd2M.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // MogGameEndR
            // 
            this.MogGameEndR.BackColor = System.Drawing.Color.Transparent;
            this.MogGameEndR.Font = new System.Drawing.Font("Lucida Sans Typewriter", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MogGameEndR.ForeColor = System.Drawing.Color.White;
            this.MogGameEndR.Location = new System.Drawing.Point(204, 23);
            this.MogGameEndR.Name = "MogGameEndR";
            this.MogGameEndR.Size = new System.Drawing.Size(109, 170);
            this.MogGameEndR.TabIndex = 8;
            this.MogGameEndR.Text = "00:00:00\r\n00:00:00\r\n00:00:00\r\n00:00:00\r\n00:00:00\r\n00:00:00\r\n00:00:00\r\n00:00:00";
            this.MogGameEndR.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label22
            // 
            this.label22.BackColor = System.Drawing.Color.Transparent;
            this.label22.Font = new System.Drawing.Font("Lucida Sans Typewriter", 13F);
            this.label22.ForeColor = System.Drawing.Color.White;
            this.label22.Location = new System.Drawing.Point(3, 24);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(90, 80);
            this.label22.TabIndex = 2;
            this.label22.Text = "I : \r\nII : \r\nIII : \r\nIV : ";
            this.label22.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label18
            // 
            this.label18.BackColor = System.Drawing.Color.Transparent;
            this.label18.Font = new System.Drawing.Font("Lucida Sans Typewriter", 13F);
            this.label18.ForeColor = System.Drawing.Color.White;
            this.label18.Location = new System.Drawing.Point(3, 3);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(391, 21);
            this.label18.TabIndex = 1;
            this.label18.Text = "End Times";
            this.label18.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label15
            // 
            this.label15.BackColor = System.Drawing.Color.Transparent;
            this.label15.Font = new System.Drawing.Font("Lucida Sans Typewriter", 13F);
            this.label15.ForeColor = System.Drawing.Color.White;
            this.label15.Location = new System.Drawing.Point(3, 108);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(90, 80);
            this.label15.TabIndex = 26;
            this.label15.Text = "V : \r\nVI : \r\nVII : \r\nVIII : ";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label16
            // 
            this.label16.BackColor = System.Drawing.Color.Transparent;
            this.label16.Font = new System.Drawing.Font("Lucida Sans Typewriter", 13F);
            this.label16.ForeColor = System.Drawing.Color.White;
            this.label16.Location = new System.Drawing.Point(295, 108);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(90, 80);
            this.label16.TabIndex = 29;
            this.label16.Text = " : XIII\r\n : 13-2\r\n : LR\r\n : T-0";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label17
            // 
            this.label17.BackColor = System.Drawing.Color.Transparent;
            this.label17.Font = new System.Drawing.Font("Lucida Sans Typewriter", 13F);
            this.label17.ForeColor = System.Drawing.Color.White;
            this.label17.Location = new System.Drawing.Point(295, 24);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(90, 80);
            this.label17.TabIndex = 28;
            this.label17.Text = " : IX\r\n : X\r\n : X-2\r\n : XII";
            this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label14
            // 
            this.label14.BackColor = System.Drawing.Color.Transparent;
            this.label14.Font = new System.Drawing.Font("Lucida Sans Typewriter", 13F);
            this.label14.ForeColor = System.Drawing.Color.White;
            this.label14.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.label14.Location = new System.Drawing.Point(76, 194);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(90, 21);
            this.label14.TabIndex = 27;
            this.label14.Text = "XV : ";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // infochoco
            // 
            this.infochoco.Controls.Add(this.chocosplits);
            this.infochoco.Controls.Add(this.chococategory);
            this.infochoco.Controls.Add(this.chocogames);
            this.infochoco.Controls.Add(this.tabPage7);
            this.infochoco.Location = new System.Drawing.Point(426, 295);
            this.infochoco.Name = "infochoco";
            this.infochoco.SelectedIndex = 0;
            this.infochoco.Size = new System.Drawing.Size(408, 254);
            this.infochoco.TabIndex = 12;
            this.infochoco.Selected += new System.Windows.Forms.TabControlEventHandler(this.ChocoTab_Clicked);
            // 
            // chocosplits
            // 
            this.chocosplits.BackColor = System.Drawing.Color.Black;
            this.chocosplits.BackgroundImage = global::ffrelaytoolv1.Properties.Resources.choco_box;
            this.chocosplits.Controls.Add(this.label33);
            this.chocosplits.Controls.Add(this.label32);
            this.chocosplits.Controls.Add(this.ChocoSplitVs2);
            this.chocosplits.Controls.Add(this.ChocoSplitVs1);
            this.chocosplits.Controls.Add(this.ChocoSplitTime4);
            this.chocosplits.Controls.Add(this.ChocoSplitName4);
            this.chocosplits.Controls.Add(this.ChocoSplitTime3);
            this.chocosplits.Controls.Add(this.ChocoSplitTime2);
            this.chocosplits.Controls.Add(this.ChocoSplitTime1);
            this.chocosplits.Controls.Add(this.ChocoSplitName3);
            this.chocosplits.Controls.Add(this.ChocoSplitName2);
            this.chocosplits.Controls.Add(this.ChocoSplitName1);
            this.chocosplits.Location = new System.Drawing.Point(4, 22);
            this.chocosplits.Name = "chocosplits";
            this.chocosplits.Padding = new System.Windows.Forms.Padding(3);
            this.chocosplits.Size = new System.Drawing.Size(400, 228);
            this.chocosplits.TabIndex = 0;
            this.chocosplits.Text = "C: Splits";
            // 
            // label33
            // 
            this.label33.BackColor = System.Drawing.Color.Transparent;
            this.label33.Font = new System.Drawing.Font("Lucida Sans Typewriter", 16F);
            this.label33.ForeColor = System.Drawing.Color.White;
            this.label33.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.label33.Location = new System.Drawing.Point(3, 157);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(228, 29);
            this.label33.TabIndex = 17;
            this.label33.Text = "Team Mog:";
            this.label33.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label32
            // 
            this.label32.BackColor = System.Drawing.Color.Transparent;
            this.label32.Font = new System.Drawing.Font("Lucida Sans Typewriter", 16F);
            this.label32.ForeColor = System.Drawing.Color.White;
            this.label32.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.label32.Location = new System.Drawing.Point(3, 186);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(228, 29);
            this.label32.TabIndex = 16;
            this.label32.Text = "Team Tonberry:";
            this.label32.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // ChocoSplitVs2
            // 
            this.ChocoSplitVs2.BackColor = System.Drawing.Color.Transparent;
            this.ChocoSplitVs2.Font = new System.Drawing.Font("Lucida Sans Typewriter", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ChocoSplitVs2.ForeColor = System.Drawing.Color.White;
            this.ChocoSplitVs2.Location = new System.Drawing.Point(242, 186);
            this.ChocoSplitVs2.Name = "ChocoSplitVs2";
            this.ChocoSplitVs2.Size = new System.Drawing.Size(140, 29);
            this.ChocoSplitVs2.TabIndex = 12;
            this.ChocoSplitVs2.Text = "00:00:00";
            this.ChocoSplitVs2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // ChocoSplitVs1
            // 
            this.ChocoSplitVs1.BackColor = System.Drawing.Color.Transparent;
            this.ChocoSplitVs1.Font = new System.Drawing.Font("Lucida Sans Typewriter", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ChocoSplitVs1.ForeColor = System.Drawing.Color.White;
            this.ChocoSplitVs1.Location = new System.Drawing.Point(242, 157);
            this.ChocoSplitVs1.Name = "ChocoSplitVs1";
            this.ChocoSplitVs1.Size = new System.Drawing.Size(140, 29);
            this.ChocoSplitVs1.TabIndex = 11;
            this.ChocoSplitVs1.Text = "00:00:00";
            this.ChocoSplitVs1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // ChocoSplitTime4
            // 
            this.ChocoSplitTime4.BackColor = System.Drawing.Color.Transparent;
            this.ChocoSplitTime4.Font = new System.Drawing.Font("Lucida Sans Typewriter", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ChocoSplitTime4.ForeColor = System.Drawing.Color.White;
            this.ChocoSplitTime4.Location = new System.Drawing.Point(265, 93);
            this.ChocoSplitTime4.Name = "ChocoSplitTime4";
            this.ChocoSplitTime4.Size = new System.Drawing.Size(117, 29);
            this.ChocoSplitTime4.TabIndex = 10;
            this.ChocoSplitTime4.Text = "00:00:00";
            this.ChocoSplitTime4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // ChocoSplitName4
            // 
            this.ChocoSplitName4.BackColor = System.Drawing.Color.Transparent;
            this.ChocoSplitName4.Font = new System.Drawing.Font("Lucida Sans Typewriter", 16F);
            this.ChocoSplitName4.ForeColor = System.Drawing.Color.White;
            this.ChocoSplitName4.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.ChocoSplitName4.Location = new System.Drawing.Point(3, 93);
            this.ChocoSplitName4.Name = "ChocoSplitName4";
            this.ChocoSplitName4.Size = new System.Drawing.Size(256, 29);
            this.ChocoSplitName4.TabIndex = 9;
            this.ChocoSplitName4.Text = "Sinspawn Geneaux";
            this.ChocoSplitName4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // ChocoSplitTime3
            // 
            this.ChocoSplitTime3.BackColor = System.Drawing.Color.Transparent;
            this.ChocoSplitTime3.Font = new System.Drawing.Font("Lucida Sans Typewriter", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ChocoSplitTime3.ForeColor = System.Drawing.Color.White;
            this.ChocoSplitTime3.Location = new System.Drawing.Point(265, 64);
            this.ChocoSplitTime3.Name = "ChocoSplitTime3";
            this.ChocoSplitTime3.Size = new System.Drawing.Size(117, 29);
            this.ChocoSplitTime3.TabIndex = 8;
            this.ChocoSplitTime3.Text = "00:00:00";
            this.ChocoSplitTime3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // ChocoSplitTime2
            // 
            this.ChocoSplitTime2.BackColor = System.Drawing.Color.Transparent;
            this.ChocoSplitTime2.Font = new System.Drawing.Font("Lucida Sans Typewriter", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ChocoSplitTime2.ForeColor = System.Drawing.Color.White;
            this.ChocoSplitTime2.Location = new System.Drawing.Point(265, 35);
            this.ChocoSplitTime2.Name = "ChocoSplitTime2";
            this.ChocoSplitTime2.Size = new System.Drawing.Size(117, 29);
            this.ChocoSplitTime2.TabIndex = 7;
            this.ChocoSplitTime2.Text = "00:00:00";
            this.ChocoSplitTime2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // ChocoSplitTime1
            // 
            this.ChocoSplitTime1.BackColor = System.Drawing.Color.Transparent;
            this.ChocoSplitTime1.Font = new System.Drawing.Font("Lucida Sans Typewriter", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ChocoSplitTime1.ForeColor = System.Drawing.Color.White;
            this.ChocoSplitTime1.Location = new System.Drawing.Point(265, 6);
            this.ChocoSplitTime1.Name = "ChocoSplitTime1";
            this.ChocoSplitTime1.Size = new System.Drawing.Size(117, 29);
            this.ChocoSplitTime1.TabIndex = 6;
            this.ChocoSplitTime1.Text = "00:00:00";
            this.ChocoSplitTime1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // ChocoSplitName3
            // 
            this.ChocoSplitName3.BackColor = System.Drawing.Color.Transparent;
            this.ChocoSplitName3.Font = new System.Drawing.Font("Lucida Sans Typewriter", 16F);
            this.ChocoSplitName3.ForeColor = System.Drawing.Color.White;
            this.ChocoSplitName3.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.ChocoSplitName3.Location = new System.Drawing.Point(3, 64);
            this.ChocoSplitName3.Name = "ChocoSplitName3";
            this.ChocoSplitName3.Size = new System.Drawing.Size(256, 29);
            this.ChocoSplitName3.TabIndex = 5;
            this.ChocoSplitName3.Text = "Sinspawn Geneaux";
            this.ChocoSplitName3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // ChocoSplitName2
            // 
            this.ChocoSplitName2.BackColor = System.Drawing.Color.Transparent;
            this.ChocoSplitName2.Font = new System.Drawing.Font("Lucida Sans Typewriter", 16F);
            this.ChocoSplitName2.ForeColor = System.Drawing.Color.White;
            this.ChocoSplitName2.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.ChocoSplitName2.Location = new System.Drawing.Point(3, 35);
            this.ChocoSplitName2.Name = "ChocoSplitName2";
            this.ChocoSplitName2.Size = new System.Drawing.Size(256, 29);
            this.ChocoSplitName2.TabIndex = 4;
            this.ChocoSplitName2.Text = "Final Fantasy 13-2";
            this.ChocoSplitName2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // ChocoSplitName1
            // 
            this.ChocoSplitName1.BackColor = System.Drawing.Color.Transparent;
            this.ChocoSplitName1.Font = new System.Drawing.Font("Lucida Sans Typewriter", 16F);
            this.ChocoSplitName1.ForeColor = System.Drawing.Color.White;
            this.ChocoSplitName1.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.ChocoSplitName1.Location = new System.Drawing.Point(3, 6);
            this.ChocoSplitName1.Name = "ChocoSplitName1";
            this.ChocoSplitName1.Size = new System.Drawing.Size(256, 29);
            this.ChocoSplitName1.TabIndex = 3;
            this.ChocoSplitName1.Text = "Proto fal\'Cie Adam";
            this.ChocoSplitName1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // chococategory
            // 
            this.chococategory.BackColor = System.Drawing.Color.Black;
            this.chococategory.BackgroundImage = global::ffrelaytoolv1.Properties.Resources.choco_box;
            this.chococategory.Controls.Add(this.ChocoCommentary);
            this.chococategory.Controls.Add(this.label36);
            this.chococategory.Controls.Add(this.ChocoInfoCat3);
            this.chococategory.Controls.Add(this.ChocoInfoCat2);
            this.chococategory.Controls.Add(this.ChocoInfoCat1);
            this.chococategory.Location = new System.Drawing.Point(4, 22);
            this.chococategory.Name = "chococategory";
            this.chococategory.Padding = new System.Windows.Forms.Padding(3);
            this.chococategory.Size = new System.Drawing.Size(400, 228);
            this.chococategory.TabIndex = 1;
            this.chococategory.Text = "C: Cats";
            // 
            // ChocoCommentary
            // 
            this.ChocoCommentary.BackColor = System.Drawing.Color.Transparent;
            this.ChocoCommentary.Font = new System.Drawing.Font("Lucida Sans Typewriter", 16F);
            this.ChocoCommentary.ForeColor = System.Drawing.Color.White;
            this.ChocoCommentary.Location = new System.Drawing.Point(3, 143);
            this.ChocoCommentary.Name = "ChocoCommentary";
            this.ChocoCommentary.Size = new System.Drawing.Size(394, 81);
            this.ChocoCommentary.TabIndex = 6;
            this.ChocoCommentary.Text = "Commentators";
            this.ChocoCommentary.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label36
            // 
            this.label36.BackColor = System.Drawing.Color.Transparent;
            this.label36.Font = new System.Drawing.Font("Lucida Sans Typewriter", 16F);
            this.label36.ForeColor = System.Drawing.Color.White;
            this.label36.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.label36.Location = new System.Drawing.Point(3, 108);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(391, 35);
            this.label36.TabIndex = 5;
            this.label36.Text = "Commentators:";
            this.label36.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // ChocoInfoCat3
            // 
            this.ChocoInfoCat3.BackColor = System.Drawing.Color.Transparent;
            this.ChocoInfoCat3.Font = new System.Drawing.Font("Lucida Sans Typewriter", 16F);
            this.ChocoInfoCat3.ForeColor = System.Drawing.Color.White;
            this.ChocoInfoCat3.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.ChocoInfoCat3.Location = new System.Drawing.Point(3, 73);
            this.ChocoInfoCat3.Name = "ChocoInfoCat3";
            this.ChocoInfoCat3.Size = new System.Drawing.Size(391, 35);
            this.ChocoInfoCat3.TabIndex = 4;
            this.ChocoInfoCat3.Text = "ChocoCategory";
            this.ChocoInfoCat3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // ChocoInfoCat2
            // 
            this.ChocoInfoCat2.BackColor = System.Drawing.Color.Transparent;
            this.ChocoInfoCat2.Font = new System.Drawing.Font("Lucida Sans Typewriter", 16F);
            this.ChocoInfoCat2.ForeColor = System.Drawing.Color.White;
            this.ChocoInfoCat2.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.ChocoInfoCat2.Location = new System.Drawing.Point(3, 38);
            this.ChocoInfoCat2.Name = "ChocoInfoCat2";
            this.ChocoInfoCat2.Size = new System.Drawing.Size(391, 35);
            this.ChocoInfoCat2.TabIndex = 3;
            this.ChocoInfoCat2.Text = "ChocoCategory";
            this.ChocoInfoCat2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // ChocoInfoCat1
            // 
            this.ChocoInfoCat1.BackColor = System.Drawing.Color.Transparent;
            this.ChocoInfoCat1.Font = new System.Drawing.Font("Lucida Sans Typewriter", 16F);
            this.ChocoInfoCat1.ForeColor = System.Drawing.Color.White;
            this.ChocoInfoCat1.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.ChocoInfoCat1.Location = new System.Drawing.Point(3, 3);
            this.ChocoInfoCat1.Name = "ChocoInfoCat1";
            this.ChocoInfoCat1.Size = new System.Drawing.Size(391, 35);
            this.ChocoInfoCat1.TabIndex = 2;
            this.ChocoInfoCat1.Text = "ChocoCategory";
            this.ChocoInfoCat1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // chocogames
            // 
            this.chocogames.BackColor = System.Drawing.Color.Black;
            this.chocogames.BackgroundImage = global::ffrelaytoolv1.Properties.Resources.choco_box;
            this.chocogames.Controls.Add(this.ChocoGameTimersL);
            this.chocogames.Controls.Add(this.ChocoGameTimersR);
            this.chocogames.Controls.Add(this.ChocoGameTimers2M);
            this.chocogames.Controls.Add(this.label11);
            this.chocogames.Controls.Add(this.label3);
            this.chocogames.Controls.Add(this.label10);
            this.chocogames.Controls.Add(this.label12);
            this.chocogames.Controls.Add(this.label13);
            this.chocogames.Controls.Add(this.label1);
            this.chocogames.Location = new System.Drawing.Point(4, 22);
            this.chocogames.Name = "chocogames";
            this.chocogames.Size = new System.Drawing.Size(400, 228);
            this.chocogames.TabIndex = 2;
            this.chocogames.Text = "C: Times";
            // 
            // ChocoGameTimersL
            // 
            this.ChocoGameTimersL.BackColor = System.Drawing.Color.Transparent;
            this.ChocoGameTimersL.Font = new System.Drawing.Font("Lucida Sans Typewriter", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ChocoGameTimersL.ForeColor = System.Drawing.Color.White;
            this.ChocoGameTimersL.Location = new System.Drawing.Point(76, 23);
            this.ChocoGameTimersL.Name = "ChocoGameTimersL";
            this.ChocoGameTimersL.Size = new System.Drawing.Size(109, 170);
            this.ChocoGameTimersL.TabIndex = 34;
            this.ChocoGameTimersL.Text = "00:00:00\r\n00:00:00\r\n00:00:00\r\n00:00:00\r\n00:00:00\r\n00:00:00\r\n00:00:00\r\n00:00:00";
            this.ChocoGameTimersL.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // ChocoGameTimersR
            // 
            this.ChocoGameTimersR.BackColor = System.Drawing.Color.Transparent;
            this.ChocoGameTimersR.Font = new System.Drawing.Font("Lucida Sans Typewriter", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ChocoGameTimersR.ForeColor = System.Drawing.Color.White;
            this.ChocoGameTimersR.Location = new System.Drawing.Point(204, 23);
            this.ChocoGameTimersR.Name = "ChocoGameTimersR";
            this.ChocoGameTimersR.Size = new System.Drawing.Size(109, 170);
            this.ChocoGameTimersR.TabIndex = 33;
            this.ChocoGameTimersR.Text = "00:00:00\r\n00:00:00\r\n00:00:00\r\n00:00:00\r\n00:00:00\r\n00:00:00\r\n00:00:00\r\n00:00:00";
            this.ChocoGameTimersR.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // ChocoGameTimers2M
            // 
            this.ChocoGameTimers2M.BackColor = System.Drawing.Color.Transparent;
            this.ChocoGameTimers2M.Font = new System.Drawing.Font("Lucida Sans Typewriter", 13F);
            this.ChocoGameTimers2M.ForeColor = System.Drawing.Color.White;
            this.ChocoGameTimers2M.Location = new System.Drawing.Point(145, 194);
            this.ChocoGameTimers2M.Name = "ChocoGameTimers2M";
            this.ChocoGameTimers2M.Size = new System.Drawing.Size(110, 21);
            this.ChocoGameTimers2M.TabIndex = 21;
            this.ChocoGameTimers2M.Text = "00:00:00";
            this.ChocoGameTimers2M.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label11
            // 
            this.label11.BackColor = System.Drawing.Color.Transparent;
            this.label11.Font = new System.Drawing.Font("Lucida Sans Typewriter", 13F);
            this.label11.ForeColor = System.Drawing.Color.White;
            this.label11.Location = new System.Drawing.Point(0, 3);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(400, 21);
            this.label11.TabIndex = 6;
            this.label11.Text = "Game Times";
            this.label11.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Lucida Sans Typewriter", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(3, 24);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(90, 80);
            this.label3.TabIndex = 3;
            this.label3.Text = "I : \r\nII : \r\nIII : \r\nIV : ";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label10
            // 
            this.label10.BackColor = System.Drawing.Color.Transparent;
            this.label10.Font = new System.Drawing.Font("Lucida Sans Typewriter", 13F);
            this.label10.ForeColor = System.Drawing.Color.White;
            this.label10.Location = new System.Drawing.Point(3, 108);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(90, 80);
            this.label10.TabIndex = 22;
            this.label10.Text = "V : \r\nVI : \r\nVII : \r\nVIII : ";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label12
            // 
            this.label12.BackColor = System.Drawing.Color.Transparent;
            this.label12.Font = new System.Drawing.Font("Lucida Sans Typewriter", 13F);
            this.label12.ForeColor = System.Drawing.Color.White;
            this.label12.Location = new System.Drawing.Point(295, 108);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(90, 80);
            this.label12.TabIndex = 25;
            this.label12.Text = " : XIII\r\n : 13-2\r\n : LR\r\n : T-0";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label13
            // 
            this.label13.BackColor = System.Drawing.Color.Transparent;
            this.label13.Font = new System.Drawing.Font("Lucida Sans Typewriter", 13F);
            this.label13.ForeColor = System.Drawing.Color.White;
            this.label13.Location = new System.Drawing.Point(295, 24);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(90, 80);
            this.label13.TabIndex = 24;
            this.label13.Text = " : IX\r\n : X\r\n : X-2\r\n : XII";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Lucida Sans Typewriter", 13F);
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.label1.Location = new System.Drawing.Point(76, 194);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(90, 21);
            this.label1.TabIndex = 23;
            this.label1.Text = "XV : ";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tabPage7
            // 
            this.tabPage7.BackColor = System.Drawing.Color.Black;
            this.tabPage7.BackgroundImage = global::ffrelaytoolv1.Properties.Resources.choco_box;
            this.tabPage7.Controls.Add(this.ChocoGameEndL);
            this.tabPage7.Controls.Add(this.ChocoGameEndR);
            this.tabPage7.Controls.Add(this.ChocoGameEnd2M);
            this.tabPage7.Controls.Add(this.label23);
            this.tabPage7.Controls.Add(this.label20);
            this.tabPage7.Controls.Add(this.label19);
            this.tabPage7.Controls.Add(this.label21);
            this.tabPage7.Controls.Add(this.label24);
            this.tabPage7.Controls.Add(this.label25);
            this.tabPage7.Location = new System.Drawing.Point(4, 22);
            this.tabPage7.Name = "tabPage7";
            this.tabPage7.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage7.Size = new System.Drawing.Size(400, 228);
            this.tabPage7.TabIndex = 5;
            this.tabPage7.Text = "C: End";
            // 
            // ChocoGameEndL
            // 
            this.ChocoGameEndL.BackColor = System.Drawing.Color.Transparent;
            this.ChocoGameEndL.Font = new System.Drawing.Font("Lucida Sans Typewriter", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ChocoGameEndL.ForeColor = System.Drawing.Color.White;
            this.ChocoGameEndL.Location = new System.Drawing.Point(76, 23);
            this.ChocoGameEndL.Name = "ChocoGameEndL";
            this.ChocoGameEndL.Size = new System.Drawing.Size(109, 170);
            this.ChocoGameEndL.TabIndex = 36;
            this.ChocoGameEndL.Text = "00:00:00\r\n00:00:00\r\n00:00:00\r\n00:00:00\r\n00:00:00\r\n00:00:00\r\n00:00:00\r\n00:00:00";
            this.ChocoGameEndL.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // ChocoGameEndR
            // 
            this.ChocoGameEndR.BackColor = System.Drawing.Color.Transparent;
            this.ChocoGameEndR.Font = new System.Drawing.Font("Lucida Sans Typewriter", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ChocoGameEndR.ForeColor = System.Drawing.Color.White;
            this.ChocoGameEndR.Location = new System.Drawing.Point(204, 23);
            this.ChocoGameEndR.Name = "ChocoGameEndR";
            this.ChocoGameEndR.Size = new System.Drawing.Size(109, 170);
            this.ChocoGameEndR.TabIndex = 35;
            this.ChocoGameEndR.Text = "00:00:00\r\n00:00:00\r\n00:00:00\r\n00:00:00\r\n00:00:00\r\n00:00:00\r\n00:00:00\r\n00:00:00";
            this.ChocoGameEndR.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // ChocoGameEnd2M
            // 
            this.ChocoGameEnd2M.BackColor = System.Drawing.Color.Transparent;
            this.ChocoGameEnd2M.Font = new System.Drawing.Font("Lucida Sans Typewriter", 13F);
            this.ChocoGameEnd2M.ForeColor = System.Drawing.Color.White;
            this.ChocoGameEnd2M.Location = new System.Drawing.Point(145, 194);
            this.ChocoGameEnd2M.Name = "ChocoGameEnd2M";
            this.ChocoGameEnd2M.Size = new System.Drawing.Size(110, 21);
            this.ChocoGameEnd2M.TabIndex = 17;
            this.ChocoGameEnd2M.Text = "00:00:00";
            this.ChocoGameEnd2M.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label23
            // 
            this.label23.BackColor = System.Drawing.Color.Transparent;
            this.label23.Font = new System.Drawing.Font("Lucida Sans Typewriter", 13F);
            this.label23.ForeColor = System.Drawing.Color.White;
            this.label23.Location = new System.Drawing.Point(3, 24);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(90, 80);
            this.label23.TabIndex = 3;
            this.label23.Text = "I : \r\nII : \r\nIII : \r\nIV : ";
            this.label23.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label20
            // 
            this.label20.BackColor = System.Drawing.Color.Transparent;
            this.label20.Font = new System.Drawing.Font("Lucida Sans Typewriter", 13F);
            this.label20.ForeColor = System.Drawing.Color.White;
            this.label20.Location = new System.Drawing.Point(3, 3);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(394, 21);
            this.label20.TabIndex = 2;
            this.label20.Text = "End Times";
            this.label20.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label19
            // 
            this.label19.BackColor = System.Drawing.Color.Transparent;
            this.label19.Font = new System.Drawing.Font("Lucida Sans Typewriter", 13F);
            this.label19.ForeColor = System.Drawing.Color.White;
            this.label19.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.label19.Location = new System.Drawing.Point(76, 194);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(90, 21);
            this.label19.TabIndex = 27;
            this.label19.Text = "XV : ";
            this.label19.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label21
            // 
            this.label21.BackColor = System.Drawing.Color.Transparent;
            this.label21.Font = new System.Drawing.Font("Lucida Sans Typewriter", 13F);
            this.label21.ForeColor = System.Drawing.Color.White;
            this.label21.Location = new System.Drawing.Point(3, 108);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(90, 80);
            this.label21.TabIndex = 26;
            this.label21.Text = "V : \r\nVI : \r\nVII : \r\nVIII : ";
            this.label21.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label24
            // 
            this.label24.BackColor = System.Drawing.Color.Transparent;
            this.label24.Font = new System.Drawing.Font("Lucida Sans Typewriter", 13F);
            this.label24.ForeColor = System.Drawing.Color.White;
            this.label24.Location = new System.Drawing.Point(295, 108);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(90, 80);
            this.label24.TabIndex = 29;
            this.label24.Text = " : XIII\r\n : 13-2\r\n : LR\r\n : T-0";
            this.label24.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label25
            // 
            this.label25.BackColor = System.Drawing.Color.Transparent;
            this.label25.Font = new System.Drawing.Font("Lucida Sans Typewriter", 13F);
            this.label25.ForeColor = System.Drawing.Color.White;
            this.label25.Location = new System.Drawing.Point(295, 24);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(90, 80);
            this.label25.TabIndex = 28;
            this.label25.Text = " : IX\r\n : X\r\n : X-2\r\n : XII";
            this.label25.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // MogSplit
            // 
            this.MogSplit.BackColor = System.Drawing.Color.CornflowerBlue;
            this.MogSplit.Location = new System.Drawing.Point(16, 211);
            this.MogSplit.Name = "MogSplit";
            this.MogSplit.Size = new System.Drawing.Size(400, 54);
            this.MogSplit.TabIndex = 13;
            this.MogSplit.Text = "Team Mog Split";
            this.MogSplit.UseVisualStyleBackColor = false;
            this.MogSplit.Click += new System.EventHandler(this.MogSplit_Click);
            // 
            // ChocoSplit
            // 
            this.ChocoSplit.BackColor = System.Drawing.Color.Orchid;
            this.ChocoSplit.Location = new System.Drawing.Point(430, 211);
            this.ChocoSplit.Name = "ChocoSplit";
            this.ChocoSplit.Size = new System.Drawing.Size(400, 54);
            this.ChocoSplit.TabIndex = 14;
            this.ChocoSplit.Text = "Team Choco Split";
            this.ChocoSplit.UseVisualStyleBackColor = false;
            this.ChocoSplit.Click += new System.EventHandler(this.ChocoSplit_Click);
            // 
            // MogTimer
            // 
            this.MogTimer.BackColor = System.Drawing.Color.White;
            this.MogTimer.Font = new System.Drawing.Font("Microsoft Sans Serif", 40F);
            this.MogTimer.Location = new System.Drawing.Point(89, 132);
            this.MogTimer.Margin = new System.Windows.Forms.Padding(0);
            this.MogTimer.Name = "MogTimer";
            this.MogTimer.Size = new System.Drawing.Size(254, 64);
            this.MogTimer.TabIndex = 15;
            this.MogTimer.Text = "00:00:00";
            this.MogTimer.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // ChocoTimer
            // 
            this.ChocoTimer.BackColor = System.Drawing.Color.White;
            this.ChocoTimer.Font = new System.Drawing.Font("Microsoft Sans Serif", 40F);
            this.ChocoTimer.Location = new System.Drawing.Point(503, 132);
            this.ChocoTimer.Margin = new System.Windows.Forms.Padding(0);
            this.ChocoTimer.Name = "ChocoTimer";
            this.ChocoTimer.Size = new System.Drawing.Size(254, 64);
            this.ChocoTimer.TabIndex = 16;
            this.ChocoTimer.Text = "00:00:00";
            this.ChocoTimer.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // TonbTimer
            // 
            this.TonbTimer.BackColor = System.Drawing.Color.White;
            this.TonbTimer.Font = new System.Drawing.Font("Microsoft Sans Serif", 40F);
            this.TonbTimer.Location = new System.Drawing.Point(916, 132);
            this.TonbTimer.Margin = new System.Windows.Forms.Padding(0);
            this.TonbTimer.Name = "TonbTimer";
            this.TonbTimer.Size = new System.Drawing.Size(254, 64);
            this.TonbTimer.TabIndex = 17;
            this.TonbTimer.Text = "00:00:00";
            this.TonbTimer.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // infotonb
            // 
            this.infotonb.Controls.Add(this.tabPage9);
            this.infotonb.Controls.Add(this.tabPage10);
            this.infotonb.Controls.Add(this.tabPage11);
            this.infotonb.Controls.Add(this.tabPage14);
            this.infotonb.Location = new System.Drawing.Point(844, 295);
            this.infotonb.Name = "infotonb";
            this.infotonb.SelectedIndex = 0;
            this.infotonb.Size = new System.Drawing.Size(408, 254);
            this.infotonb.TabIndex = 18;
            this.infotonb.Selected += new System.Windows.Forms.TabControlEventHandler(this.TonbTab_Clicked);
            // 
            // tabPage9
            // 
            this.tabPage9.BackColor = System.Drawing.Color.Black;
            this.tabPage9.BackgroundImage = global::ffrelaytoolv1.Properties.Resources.tonb_box;
            this.tabPage9.Controls.Add(this.TonbSplitVs2);
            this.tabPage9.Controls.Add(this.label35);
            this.tabPage9.Controls.Add(this.label34);
            this.tabPage9.Controls.Add(this.TonbSplitVs1);
            this.tabPage9.Controls.Add(this.TonbSplitTime4);
            this.tabPage9.Controls.Add(this.TonbSplitName4);
            this.tabPage9.Controls.Add(this.TonbSplitTime3);
            this.tabPage9.Controls.Add(this.TonbSplitTime2);
            this.tabPage9.Controls.Add(this.TonbSplitTime1);
            this.tabPage9.Controls.Add(this.TonbSplitName3);
            this.tabPage9.Controls.Add(this.TonbSplitName2);
            this.tabPage9.Controls.Add(this.TonbSplitName1);
            this.tabPage9.Location = new System.Drawing.Point(4, 22);
            this.tabPage9.Name = "tabPage9";
            this.tabPage9.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage9.Size = new System.Drawing.Size(400, 228);
            this.tabPage9.TabIndex = 0;
            this.tabPage9.Text = "T: Splits";
            // 
            // TonbSplitVs2
            // 
            this.TonbSplitVs2.BackColor = System.Drawing.Color.Transparent;
            this.TonbSplitVs2.Font = new System.Drawing.Font("Lucida Sans Typewriter", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TonbSplitVs2.ForeColor = System.Drawing.Color.White;
            this.TonbSplitVs2.Location = new System.Drawing.Point(242, 186);
            this.TonbSplitVs2.Name = "TonbSplitVs2";
            this.TonbSplitVs2.Size = new System.Drawing.Size(140, 29);
            this.TonbSplitVs2.TabIndex = 20;
            this.TonbSplitVs2.Text = "00:00:00";
            this.TonbSplitVs2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label35
            // 
            this.label35.BackColor = System.Drawing.Color.Transparent;
            this.label35.Font = new System.Drawing.Font("Lucida Sans Typewriter", 16F);
            this.label35.ForeColor = System.Drawing.Color.White;
            this.label35.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.label35.Location = new System.Drawing.Point(3, 186);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(228, 29);
            this.label35.TabIndex = 19;
            this.label35.Text = "Team Choco:";
            this.label35.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label34
            // 
            this.label34.BackColor = System.Drawing.Color.Transparent;
            this.label34.Font = new System.Drawing.Font("Lucida Sans Typewriter", 16F);
            this.label34.ForeColor = System.Drawing.Color.White;
            this.label34.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.label34.Location = new System.Drawing.Point(3, 157);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(228, 29);
            this.label34.TabIndex = 18;
            this.label34.Text = "Team Mog:";
            this.label34.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // TonbSplitVs1
            // 
            this.TonbSplitVs1.BackColor = System.Drawing.Color.Transparent;
            this.TonbSplitVs1.Font = new System.Drawing.Font("Lucida Sans Typewriter", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TonbSplitVs1.ForeColor = System.Drawing.Color.White;
            this.TonbSplitVs1.Location = new System.Drawing.Point(242, 157);
            this.TonbSplitVs1.Name = "TonbSplitVs1";
            this.TonbSplitVs1.Size = new System.Drawing.Size(140, 29);
            this.TonbSplitVs1.TabIndex = 12;
            this.TonbSplitVs1.Text = "00:00:00";
            this.TonbSplitVs1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // TonbSplitTime4
            // 
            this.TonbSplitTime4.BackColor = System.Drawing.Color.Transparent;
            this.TonbSplitTime4.Font = new System.Drawing.Font("Lucida Sans Typewriter", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TonbSplitTime4.ForeColor = System.Drawing.Color.White;
            this.TonbSplitTime4.Location = new System.Drawing.Point(265, 93);
            this.TonbSplitTime4.Name = "TonbSplitTime4";
            this.TonbSplitTime4.Size = new System.Drawing.Size(117, 29);
            this.TonbSplitTime4.TabIndex = 10;
            this.TonbSplitTime4.Text = "00:00:00";
            this.TonbSplitTime4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // TonbSplitName4
            // 
            this.TonbSplitName4.BackColor = System.Drawing.Color.Transparent;
            this.TonbSplitName4.Font = new System.Drawing.Font("Lucida Sans Typewriter", 16F);
            this.TonbSplitName4.ForeColor = System.Drawing.Color.White;
            this.TonbSplitName4.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.TonbSplitName4.Location = new System.Drawing.Point(3, 93);
            this.TonbSplitName4.Name = "TonbSplitName4";
            this.TonbSplitName4.Size = new System.Drawing.Size(256, 29);
            this.TonbSplitName4.TabIndex = 9;
            this.TonbSplitName4.Text = "Sinspawn Geneaux";
            this.TonbSplitName4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // TonbSplitTime3
            // 
            this.TonbSplitTime3.BackColor = System.Drawing.Color.Transparent;
            this.TonbSplitTime3.Font = new System.Drawing.Font("Lucida Sans Typewriter", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TonbSplitTime3.ForeColor = System.Drawing.Color.White;
            this.TonbSplitTime3.Location = new System.Drawing.Point(265, 64);
            this.TonbSplitTime3.Name = "TonbSplitTime3";
            this.TonbSplitTime3.Size = new System.Drawing.Size(117, 29);
            this.TonbSplitTime3.TabIndex = 8;
            this.TonbSplitTime3.Text = "00:00:00";
            this.TonbSplitTime3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // TonbSplitTime2
            // 
            this.TonbSplitTime2.BackColor = System.Drawing.Color.Transparent;
            this.TonbSplitTime2.Font = new System.Drawing.Font("Lucida Sans Typewriter", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TonbSplitTime2.ForeColor = System.Drawing.Color.White;
            this.TonbSplitTime2.Location = new System.Drawing.Point(265, 35);
            this.TonbSplitTime2.Name = "TonbSplitTime2";
            this.TonbSplitTime2.Size = new System.Drawing.Size(117, 29);
            this.TonbSplitTime2.TabIndex = 7;
            this.TonbSplitTime2.Text = "00:00:00";
            this.TonbSplitTime2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // TonbSplitTime1
            // 
            this.TonbSplitTime1.BackColor = System.Drawing.Color.Transparent;
            this.TonbSplitTime1.Font = new System.Drawing.Font("Lucida Sans Typewriter", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TonbSplitTime1.ForeColor = System.Drawing.Color.White;
            this.TonbSplitTime1.Location = new System.Drawing.Point(265, 6);
            this.TonbSplitTime1.Name = "TonbSplitTime1";
            this.TonbSplitTime1.Size = new System.Drawing.Size(117, 29);
            this.TonbSplitTime1.TabIndex = 6;
            this.TonbSplitTime1.Text = "00:00:00";
            this.TonbSplitTime1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // TonbSplitName3
            // 
            this.TonbSplitName3.BackColor = System.Drawing.Color.Transparent;
            this.TonbSplitName3.Font = new System.Drawing.Font("Lucida Sans Typewriter", 16F);
            this.TonbSplitName3.ForeColor = System.Drawing.Color.White;
            this.TonbSplitName3.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.TonbSplitName3.Location = new System.Drawing.Point(3, 64);
            this.TonbSplitName3.Name = "TonbSplitName3";
            this.TonbSplitName3.Size = new System.Drawing.Size(256, 29);
            this.TonbSplitName3.TabIndex = 5;
            this.TonbSplitName3.Text = "Sinspawn Geneaux";
            this.TonbSplitName3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // TonbSplitName2
            // 
            this.TonbSplitName2.BackColor = System.Drawing.Color.Transparent;
            this.TonbSplitName2.Font = new System.Drawing.Font("Lucida Sans Typewriter", 16F);
            this.TonbSplitName2.ForeColor = System.Drawing.Color.White;
            this.TonbSplitName2.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.TonbSplitName2.Location = new System.Drawing.Point(3, 35);
            this.TonbSplitName2.Name = "TonbSplitName2";
            this.TonbSplitName2.Size = new System.Drawing.Size(256, 29);
            this.TonbSplitName2.TabIndex = 4;
            this.TonbSplitName2.Text = "Final Fantasy 13-2";
            this.TonbSplitName2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // TonbSplitName1
            // 
            this.TonbSplitName1.BackColor = System.Drawing.Color.Transparent;
            this.TonbSplitName1.Font = new System.Drawing.Font("Lucida Sans Typewriter", 16F);
            this.TonbSplitName1.ForeColor = System.Drawing.Color.White;
            this.TonbSplitName1.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.TonbSplitName1.Location = new System.Drawing.Point(3, 6);
            this.TonbSplitName1.Name = "TonbSplitName1";
            this.TonbSplitName1.Size = new System.Drawing.Size(256, 29);
            this.TonbSplitName1.TabIndex = 3;
            this.TonbSplitName1.Text = "Proto fal\'Cie Adam";
            this.TonbSplitName1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tabPage10
            // 
            this.tabPage10.BackColor = System.Drawing.Color.Black;
            this.tabPage10.BackgroundImage = global::ffrelaytoolv1.Properties.Resources.tonb_box;
            this.tabPage10.Controls.Add(this.TonbCommentary);
            this.tabPage10.Controls.Add(this.label38);
            this.tabPage10.Controls.Add(this.TonbInfoCat3);
            this.tabPage10.Controls.Add(this.TonbInfoCat2);
            this.tabPage10.Controls.Add(this.TonbInfoCat1);
            this.tabPage10.Location = new System.Drawing.Point(4, 22);
            this.tabPage10.Name = "tabPage10";
            this.tabPage10.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage10.Size = new System.Drawing.Size(400, 228);
            this.tabPage10.TabIndex = 1;
            this.tabPage10.Text = "T: Cats";
            // 
            // TonbCommentary
            // 
            this.TonbCommentary.BackColor = System.Drawing.Color.Transparent;
            this.TonbCommentary.Font = new System.Drawing.Font("Lucida Sans Typewriter", 16F);
            this.TonbCommentary.ForeColor = System.Drawing.Color.White;
            this.TonbCommentary.Location = new System.Drawing.Point(3, 143);
            this.TonbCommentary.Name = "TonbCommentary";
            this.TonbCommentary.Size = new System.Drawing.Size(394, 81);
            this.TonbCommentary.TabIndex = 7;
            this.TonbCommentary.Text = "Commentators";
            this.TonbCommentary.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label38
            // 
            this.label38.BackColor = System.Drawing.Color.Transparent;
            this.label38.Font = new System.Drawing.Font("Lucida Sans Typewriter", 16F);
            this.label38.ForeColor = System.Drawing.Color.White;
            this.label38.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.label38.Location = new System.Drawing.Point(3, 108);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(391, 35);
            this.label38.TabIndex = 6;
            this.label38.Text = "Commentators:";
            this.label38.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // TonbInfoCat3
            // 
            this.TonbInfoCat3.BackColor = System.Drawing.Color.Transparent;
            this.TonbInfoCat3.Font = new System.Drawing.Font("Lucida Sans Typewriter", 16F);
            this.TonbInfoCat3.ForeColor = System.Drawing.Color.White;
            this.TonbInfoCat3.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.TonbInfoCat3.Location = new System.Drawing.Point(3, 73);
            this.TonbInfoCat3.Name = "TonbInfoCat3";
            this.TonbInfoCat3.Size = new System.Drawing.Size(391, 35);
            this.TonbInfoCat3.TabIndex = 4;
            this.TonbInfoCat3.Text = "ChocoCategory";
            this.TonbInfoCat3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // TonbInfoCat2
            // 
            this.TonbInfoCat2.BackColor = System.Drawing.Color.Transparent;
            this.TonbInfoCat2.Font = new System.Drawing.Font("Lucida Sans Typewriter", 16F);
            this.TonbInfoCat2.ForeColor = System.Drawing.Color.White;
            this.TonbInfoCat2.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.TonbInfoCat2.Location = new System.Drawing.Point(3, 38);
            this.TonbInfoCat2.Name = "TonbInfoCat2";
            this.TonbInfoCat2.Size = new System.Drawing.Size(391, 35);
            this.TonbInfoCat2.TabIndex = 3;
            this.TonbInfoCat2.Text = "ChocoCategory";
            this.TonbInfoCat2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // TonbInfoCat1
            // 
            this.TonbInfoCat1.BackColor = System.Drawing.Color.Transparent;
            this.TonbInfoCat1.Font = new System.Drawing.Font("Lucida Sans Typewriter", 16F);
            this.TonbInfoCat1.ForeColor = System.Drawing.Color.White;
            this.TonbInfoCat1.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.TonbInfoCat1.Location = new System.Drawing.Point(3, 3);
            this.TonbInfoCat1.Name = "TonbInfoCat1";
            this.TonbInfoCat1.Size = new System.Drawing.Size(391, 35);
            this.TonbInfoCat1.TabIndex = 2;
            this.TonbInfoCat1.Text = "ChocoCategory";
            this.TonbInfoCat1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tabPage11
            // 
            this.tabPage11.BackColor = System.Drawing.Color.Black;
            this.tabPage11.BackgroundImage = global::ffrelaytoolv1.Properties.Resources.tonb_box;
            this.tabPage11.Controls.Add(this.TonbGameTimersL);
            this.tabPage11.Controls.Add(this.TonbGameTimersR);
            this.tabPage11.Controls.Add(this.TonbGameTimers2M);
            this.tabPage11.Controls.Add(this.label43);
            this.tabPage11.Controls.Add(this.label46);
            this.tabPage11.Controls.Add(this.label26);
            this.tabPage11.Controls.Add(this.label27);
            this.tabPage11.Controls.Add(this.label28);
            this.tabPage11.Controls.Add(this.label29);
            this.tabPage11.Location = new System.Drawing.Point(4, 22);
            this.tabPage11.Name = "tabPage11";
            this.tabPage11.Size = new System.Drawing.Size(400, 228);
            this.tabPage11.TabIndex = 2;
            this.tabPage11.Text = "T: Times";
            // 
            // TonbGameTimersL
            // 
            this.TonbGameTimersL.BackColor = System.Drawing.Color.Transparent;
            this.TonbGameTimersL.Font = new System.Drawing.Font("Lucida Sans Typewriter", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TonbGameTimersL.ForeColor = System.Drawing.Color.White;
            this.TonbGameTimersL.Location = new System.Drawing.Point(76, 23);
            this.TonbGameTimersL.Name = "TonbGameTimersL";
            this.TonbGameTimersL.Size = new System.Drawing.Size(109, 170);
            this.TonbGameTimersL.TabIndex = 38;
            this.TonbGameTimersL.Text = "00:00:00\r\n00:00:00\r\n00:00:00\r\n00:00:00\r\n00:00:00\r\n00:00:00\r\n00:00:00\r\n00:00:00";
            this.TonbGameTimersL.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // TonbGameTimersR
            // 
            this.TonbGameTimersR.BackColor = System.Drawing.Color.Transparent;
            this.TonbGameTimersR.Font = new System.Drawing.Font("Lucida Sans Typewriter", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TonbGameTimersR.ForeColor = System.Drawing.Color.White;
            this.TonbGameTimersR.Location = new System.Drawing.Point(204, 23);
            this.TonbGameTimersR.Name = "TonbGameTimersR";
            this.TonbGameTimersR.Size = new System.Drawing.Size(109, 170);
            this.TonbGameTimersR.TabIndex = 37;
            this.TonbGameTimersR.Text = "00:00:00\r\n00:00:00\r\n00:00:00\r\n00:00:00\r\n00:00:00\r\n00:00:00\r\n00:00:00\r\n00:00:00";
            this.TonbGameTimersR.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // TonbGameTimers2M
            // 
            this.TonbGameTimers2M.BackColor = System.Drawing.Color.Transparent;
            this.TonbGameTimers2M.Font = new System.Drawing.Font("Lucida Sans Typewriter", 13F);
            this.TonbGameTimers2M.ForeColor = System.Drawing.Color.White;
            this.TonbGameTimers2M.Location = new System.Drawing.Point(145, 194);
            this.TonbGameTimers2M.Name = "TonbGameTimers2M";
            this.TonbGameTimers2M.Size = new System.Drawing.Size(110, 21);
            this.TonbGameTimers2M.TabIndex = 21;
            this.TonbGameTimers2M.Text = "00:00:00";
            this.TonbGameTimers2M.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label43
            // 
            this.label43.BackColor = System.Drawing.Color.Transparent;
            this.label43.Font = new System.Drawing.Font("Lucida Sans Typewriter", 13F);
            this.label43.ForeColor = System.Drawing.Color.White;
            this.label43.Location = new System.Drawing.Point(3, 3);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(393, 21);
            this.label43.TabIndex = 6;
            this.label43.Text = "Game Times";
            this.label43.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label46
            // 
            this.label46.BackColor = System.Drawing.Color.Transparent;
            this.label46.Font = new System.Drawing.Font("Lucida Sans Typewriter", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label46.ForeColor = System.Drawing.Color.White;
            this.label46.Location = new System.Drawing.Point(3, 24);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(90, 80);
            this.label46.TabIndex = 3;
            this.label46.Text = "I : \r\nII : \r\nIII : \r\nIV : ";
            this.label46.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label26
            // 
            this.label26.BackColor = System.Drawing.Color.Transparent;
            this.label26.Font = new System.Drawing.Font("Lucida Sans Typewriter", 13F);
            this.label26.ForeColor = System.Drawing.Color.White;
            this.label26.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.label26.Location = new System.Drawing.Point(76, 194);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(90, 21);
            this.label26.TabIndex = 27;
            this.label26.Text = "XV : ";
            this.label26.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label27
            // 
            this.label27.BackColor = System.Drawing.Color.Transparent;
            this.label27.Font = new System.Drawing.Font("Lucida Sans Typewriter", 13F);
            this.label27.ForeColor = System.Drawing.Color.White;
            this.label27.Location = new System.Drawing.Point(3, 108);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(90, 80);
            this.label27.TabIndex = 26;
            this.label27.Text = "V : \r\nVI : \r\nVII : \r\nVIII : ";
            this.label27.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label28
            // 
            this.label28.BackColor = System.Drawing.Color.Transparent;
            this.label28.Font = new System.Drawing.Font("Lucida Sans Typewriter", 13F);
            this.label28.ForeColor = System.Drawing.Color.White;
            this.label28.Location = new System.Drawing.Point(295, 108);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(90, 80);
            this.label28.TabIndex = 29;
            this.label28.Text = " : XIII\r\n : 13-2\r\n : LR\r\n : T-0";
            this.label28.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label29
            // 
            this.label29.BackColor = System.Drawing.Color.Transparent;
            this.label29.Font = new System.Drawing.Font("Lucida Sans Typewriter", 13F);
            this.label29.ForeColor = System.Drawing.Color.White;
            this.label29.Location = new System.Drawing.Point(295, 24);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(90, 80);
            this.label29.TabIndex = 28;
            this.label29.Text = " : IX\r\n : X\r\n : X-2\r\n : XII";
            this.label29.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tabPage14
            // 
            this.tabPage14.BackColor = System.Drawing.Color.Black;
            this.tabPage14.BackgroundImage = global::ffrelaytoolv1.Properties.Resources.tonb_box;
            this.tabPage14.Controls.Add(this.TonbGameEndL);
            this.tabPage14.Controls.Add(this.TonbGameEndR);
            this.tabPage14.Controls.Add(this.TonbGameEnd2M);
            this.tabPage14.Controls.Add(this.label60);
            this.tabPage14.Controls.Add(this.label61);
            this.tabPage14.Controls.Add(this.label30);
            this.tabPage14.Controls.Add(this.label31);
            this.tabPage14.Controls.Add(this.label39);
            this.tabPage14.Controls.Add(this.label40);
            this.tabPage14.Location = new System.Drawing.Point(4, 22);
            this.tabPage14.Name = "tabPage14";
            this.tabPage14.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage14.Size = new System.Drawing.Size(400, 228);
            this.tabPage14.TabIndex = 5;
            this.tabPage14.Text = "T: End";
            // 
            // TonbGameEndL
            // 
            this.TonbGameEndL.BackColor = System.Drawing.Color.Transparent;
            this.TonbGameEndL.Font = new System.Drawing.Font("Lucida Sans Typewriter", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TonbGameEndL.ForeColor = System.Drawing.Color.White;
            this.TonbGameEndL.Location = new System.Drawing.Point(76, 23);
            this.TonbGameEndL.Name = "TonbGameEndL";
            this.TonbGameEndL.Size = new System.Drawing.Size(109, 170);
            this.TonbGameEndL.TabIndex = 38;
            this.TonbGameEndL.Text = "00:00:00\r\n00:00:00\r\n00:00:00\r\n00:00:00\r\n00:00:00\r\n00:00:00\r\n00:00:00\r\n00:00:00";
            this.TonbGameEndL.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // TonbGameEndR
            // 
            this.TonbGameEndR.BackColor = System.Drawing.Color.Transparent;
            this.TonbGameEndR.Font = new System.Drawing.Font("Lucida Sans Typewriter", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TonbGameEndR.ForeColor = System.Drawing.Color.White;
            this.TonbGameEndR.Location = new System.Drawing.Point(204, 23);
            this.TonbGameEndR.Name = "TonbGameEndR";
            this.TonbGameEndR.Size = new System.Drawing.Size(109, 170);
            this.TonbGameEndR.TabIndex = 37;
            this.TonbGameEndR.Text = "00:00:00\r\n00:00:00\r\n00:00:00\r\n00:00:00\r\n00:00:00\r\n00:00:00\r\n00:00:00\r\n00:00:00";
            this.TonbGameEndR.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // TonbGameEnd2M
            // 
            this.TonbGameEnd2M.BackColor = System.Drawing.Color.Transparent;
            this.TonbGameEnd2M.Font = new System.Drawing.Font("Lucida Sans Typewriter", 13F);
            this.TonbGameEnd2M.ForeColor = System.Drawing.Color.White;
            this.TonbGameEnd2M.Location = new System.Drawing.Point(145, 194);
            this.TonbGameEnd2M.Name = "TonbGameEnd2M";
            this.TonbGameEnd2M.Size = new System.Drawing.Size(110, 21);
            this.TonbGameEnd2M.TabIndex = 17;
            this.TonbGameEnd2M.Text = "00:00:00";
            this.TonbGameEnd2M.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label60
            // 
            this.label60.BackColor = System.Drawing.Color.Transparent;
            this.label60.Font = new System.Drawing.Font("Lucida Sans Typewriter", 13F);
            this.label60.ForeColor = System.Drawing.Color.White;
            this.label60.Location = new System.Drawing.Point(3, 24);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(90, 80);
            this.label60.TabIndex = 3;
            this.label60.Text = "I : \r\nII : \r\nIII : \r\nIV : ";
            this.label60.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label61
            // 
            this.label61.BackColor = System.Drawing.Color.Transparent;
            this.label61.Font = new System.Drawing.Font("Lucida Sans Typewriter", 13F);
            this.label61.ForeColor = System.Drawing.Color.White;
            this.label61.Location = new System.Drawing.Point(3, 3);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(393, 21);
            this.label61.TabIndex = 2;
            this.label61.Text = "End Times";
            this.label61.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label30
            // 
            this.label30.BackColor = System.Drawing.Color.Transparent;
            this.label30.Font = new System.Drawing.Font("Lucida Sans Typewriter", 13F);
            this.label30.ForeColor = System.Drawing.Color.White;
            this.label30.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.label30.Location = new System.Drawing.Point(76, 194);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(90, 21);
            this.label30.TabIndex = 27;
            this.label30.Text = "XV : ";
            this.label30.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label31
            // 
            this.label31.BackColor = System.Drawing.Color.Transparent;
            this.label31.Font = new System.Drawing.Font("Lucida Sans Typewriter", 13F);
            this.label31.ForeColor = System.Drawing.Color.White;
            this.label31.Location = new System.Drawing.Point(3, 108);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(90, 80);
            this.label31.TabIndex = 26;
            this.label31.Text = "V : \r\nVI : \r\nVII : \r\nVIII : ";
            this.label31.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label39
            // 
            this.label39.BackColor = System.Drawing.Color.Transparent;
            this.label39.Font = new System.Drawing.Font("Lucida Sans Typewriter", 13F);
            this.label39.ForeColor = System.Drawing.Color.White;
            this.label39.Location = new System.Drawing.Point(295, 108);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(90, 80);
            this.label39.TabIndex = 29;
            this.label39.Text = " : XIII\r\n : 13-2\r\n : LR\r\n : T-0";
            this.label39.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label40
            // 
            this.label40.BackColor = System.Drawing.Color.Transparent;
            this.label40.Font = new System.Drawing.Font("Lucida Sans Typewriter", 13F);
            this.label40.ForeColor = System.Drawing.Color.White;
            this.label40.Location = new System.Drawing.Point(295, 24);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(90, 80);
            this.label40.TabIndex = 28;
            this.label40.Text = " : IX\r\n : X\r\n : X-2\r\n : XII";
            this.label40.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // TonbSplit
            // 
            this.TonbSplit.BackColor = System.Drawing.Color.ForestGreen;
            this.TonbSplit.Location = new System.Drawing.Point(844, 211);
            this.TonbSplit.Name = "TonbSplit";
            this.TonbSplit.Size = new System.Drawing.Size(400, 54);
            this.TonbSplit.TabIndex = 19;
            this.TonbSplit.Text = "Team Tonb Split";
            this.TonbSplit.UseVisualStyleBackColor = false;
            this.TonbSplit.Click += new System.EventHandler(this.TonbSplit_Click);
            // 
            // CommUpdate
            // 
            this.CommUpdate.Location = new System.Drawing.Point(856, 23);
            this.CommUpdate.Name = "CommUpdate";
            this.CommUpdate.Size = new System.Drawing.Size(94, 50);
            this.CommUpdate.TabIndex = 20;
            this.CommUpdate.Text = "Update Text Files";
            this.CommUpdate.UseVisualStyleBackColor = true;
            this.CommUpdate.Click += new System.EventHandler(this.CommUpdate_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(1264, 561);
            this.Controls.Add(this.CommUpdate);
            this.Controls.Add(this.TonbSplit);
            this.Controls.Add(this.infotonb);
            this.Controls.Add(this.TonbTimer);
            this.Controls.Add(this.ChocoTimer);
            this.Controls.Add(this.MogTimer);
            this.Controls.Add(this.ChocoSplit);
            this.Controls.Add(this.MogSplit);
            this.Controls.Add(this.infochoco);
            this.Controls.Add(this.infomog);
            this.Controls.Add(this.ChocoIconlabel);
            this.Controls.Add(this.MogIconlabel);
            this.Controls.Add(this.ChocoIconbutton);
            this.Controls.Add(this.MogIconbutton);
            this.Controls.Add(this.stopbutton);
            this.Controls.Add(this.TonbIconlabel);
            this.Controls.Add(this.TonbIconbutton);
            this.Controls.Add(this.startbutton);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.MainTimer);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "Form1";
            this.Text = "Form1";
            this.infomog.ResumeLayout(false);
            this.mogsplits.ResumeLayout(false);
            this.mogcategory.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage5.ResumeLayout(false);
            this.infochoco.ResumeLayout(false);
            this.chocosplits.ResumeLayout(false);
            this.chococategory.ResumeLayout(false);
            this.chocogames.ResumeLayout(false);
            this.tabPage7.ResumeLayout(false);
            this.infotonb.ResumeLayout(false);
            this.tabPage9.ResumeLayout(false);
            this.tabPage10.ResumeLayout(false);
            this.tabPage11.ResumeLayout(false);
            this.tabPage14.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button startbutton;
        private System.Windows.Forms.Label MainTimer;
        private System.Windows.Forms.Button TonbIconbutton;
        private System.Windows.Forms.Label TonbIconlabel;
        private System.Windows.Forms.Button stopbutton;
        private System.Windows.Forms.Button MogIconbutton;
        private System.Windows.Forms.Button ChocoIconbutton;
        private System.Windows.Forms.Label MogIconlabel;
        private System.Windows.Forms.Label ChocoIconlabel;
        private System.Windows.Forms.TabControl infomog;
        private System.Windows.Forms.TabPage mogsplits;
        private System.Windows.Forms.TabPage mogcategory;
        private System.Windows.Forms.TabControl infochoco;
        private System.Windows.Forms.TabPage chocosplits;
        private System.Windows.Forms.TabPage chococategory;
        private System.Windows.Forms.TabPage chocogames;
        private System.Windows.Forms.Label MogInfoCat3;
        private System.Windows.Forms.Label MogInfoCat2;
        private System.Windows.Forms.Label MogInfoCat1;
        private System.Windows.Forms.Label ChocoInfoCat1;
        private System.Windows.Forms.Label ChocoInfoCat3;
        private System.Windows.Forms.Label ChocoInfoCat2;
        private System.Windows.Forms.Button MogSplit;
        private System.Windows.Forms.Button ChocoSplit;
        private System.Windows.Forms.Label MogSplitName1;
        private System.Windows.Forms.Label MogSplitName3;
        private System.Windows.Forms.Label MogSplitName2;
        private System.Windows.Forms.Label MogSplitTime1;
        private System.Windows.Forms.Label MogSplitTime2;
        private System.Windows.Forms.Label MogSplitTime3;
        private System.Windows.Forms.Label ChocoSplitName1;
        private System.Windows.Forms.Label ChocoSplitTime3;
        private System.Windows.Forms.Label ChocoSplitTime2;
        private System.Windows.Forms.Label ChocoSplitTime1;
        private System.Windows.Forms.Label ChocoSplitName3;
        private System.Windows.Forms.Label ChocoSplitName2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label MogSplitName4;
        private System.Windows.Forms.Label MogSplitTime4;
        private System.Windows.Forms.Label ChocoSplitName4;
        private System.Windows.Forms.Label ChocoSplitTime4;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.TabPage tabPage7;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label MogGameEndR;
        private System.Windows.Forms.Label MogTimer;
        private System.Windows.Forms.Label ChocoTimer;
        private System.Windows.Forms.Label TonbTimer;
        private System.Windows.Forms.TabControl infotonb;
        private System.Windows.Forms.TabPage tabPage9;
        private System.Windows.Forms.Label TonbSplitTime4;
        private System.Windows.Forms.Label TonbSplitName4;
        private System.Windows.Forms.Label TonbSplitTime3;
        private System.Windows.Forms.Label TonbSplitTime2;
        private System.Windows.Forms.Label TonbSplitTime1;
        private System.Windows.Forms.Label TonbSplitName3;
        private System.Windows.Forms.Label TonbSplitName2;
        private System.Windows.Forms.Label TonbSplitName1;
        private System.Windows.Forms.TabPage tabPage10;
        private System.Windows.Forms.Label TonbInfoCat3;
        private System.Windows.Forms.Label TonbInfoCat2;
        private System.Windows.Forms.Label TonbInfoCat1;
        private System.Windows.Forms.TabPage tabPage11;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.TabPage tabPage14;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.Button TonbSplit;
        private System.Windows.Forms.Button CommUpdate;
        private System.Windows.Forms.Label MogSplitName7;
        private System.Windows.Forms.Label MogSplitName6;
        private System.Windows.Forms.Label MogSplitVs2;
        private System.Windows.Forms.Label MogSplitVs1;
        private System.Windows.Forms.Label ChocoSplitVs1;
        private System.Windows.Forms.Label ChocoSplitVs2;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label TonbSplitVs2;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label TonbSplitVs1;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label ChocoCommentary;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label MogCommentary;
        private System.Windows.Forms.Label TonbCommentary;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label MogGameTimers2M;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label MogGameEnd2M;
        private System.Windows.Forms.Label ChocoGameTimers2M;
        private System.Windows.Forms.Label ChocoGameEnd2M;
        private System.Windows.Forms.Label TonbGameTimers2M;
        private System.Windows.Forms.Label TonbGameEnd2M;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label MogGameEndL;
        private System.Windows.Forms.Label MogGameTimersL;
        private System.Windows.Forms.Label MogGameTimersR;
        private System.Windows.Forms.Label ChocoGameTimersL;
        private System.Windows.Forms.Label ChocoGameTimersR;
        private System.Windows.Forms.Label ChocoGameEndL;
        private System.Windows.Forms.Label ChocoGameEndR;
        private System.Windows.Forms.Label TonbGameTimersL;
        private System.Windows.Forms.Label TonbGameTimersR;
        private System.Windows.Forms.Label TonbGameEndL;
        private System.Windows.Forms.Label TonbGameEndR;
    }
}

